#!/bin/bash
cd `dirname "${0}"`

        
            [ ! -z `which dmidecode` ] && sudo dmidecode > /home/lab/nautilus/logs/BYD_PB-31957_900-63701-0010-100_1423822047030_T_MOD_20220926T075019Z/dmidecode.txt
            lsb_release -a 2>&1 | tee /home/lab/nautilus/logs/BYD_PB-31957_900-63701-0010-100_1423822047030_T_MOD_20220926T075019Z/os_version.txt
            uname -a 2>&1 | tee -a /home/lab/nautilus/logs/BYD_PB-31957_900-63701-0010-100_1423822047030_T_MOD_20220926T075019Z/os_version.txt
            [ -e /home/lab/nautilus/core/UMODS1/tos-trusty_t234.img ] && printf "MODS Build Date: " ; strings /home/lab/nautilus/core/UMODS1/tos-trusty_t234.img | grep -m 1 -oP "Built:\s+\K.*" 2>&1 | tee /home/lab/nautilus/logs/BYD_PB-31957_900-63701-0010-100_1423822047030_T_MOD_20220926T075019Z/mods_build_date.txt
            [ -e /home/lab/nautilus/core/UMODS1/mods.img ] && printf "mods.img: " ; strings /home/lab/nautilus/core/UMODS1/mods.img | grep -m 1 "dev-main" 2>&1 | tee /home/lab/nautilus/logs/BYD_PB-31957_900-63701-0010-100_1423822047030_T_MOD_20220926T075019Z/mods_img_date.txt
        
    