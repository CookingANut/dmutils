# daemontool

 Usage: Often used functions for python script coding

 Install: pip install daemontool-xxx.tar.gz
