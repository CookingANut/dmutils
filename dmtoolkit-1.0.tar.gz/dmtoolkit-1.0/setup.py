from setuptools import setup
setup(
    name='dmtoolkit',
    version='1.0',
    author='Daemon Huang',
    author_email='morningrocks@outlook.com',
    url='',
    install_requires=[],
    python_requires='>=3.8',
    py_modules=['dmtoolkit'],
)
