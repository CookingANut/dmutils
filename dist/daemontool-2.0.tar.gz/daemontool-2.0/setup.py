from setuptools import setup

setup(
        name='daemontool',
        version='2.0',
        author='daemon_huang',
        install_requires=[],
        python_requires='>=3',
        py_modules=['daemontool'],
        )

        