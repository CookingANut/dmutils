# daemontool
 useful function for my own
