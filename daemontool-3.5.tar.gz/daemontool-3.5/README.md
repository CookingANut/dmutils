# daemontool

 useful function for scripts

    Author: Daemon Huang
    Date: 2022/11/30
    Version: 3.4

    - 2.0: WAR for winreg in linux system
    - 3.0: add get_path and folder_level_X_path functions
    - 3.1: update notes for all functions
    - 3.2: add parserinit function
    - 3.3: add CodeTimer class
