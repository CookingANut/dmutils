from setuptools import setup
setup(
    name='daemontool',
    version='4.1.2',
    author='Daemon Huang',
    author_email='morningrocks@outlook.com',
    url='',
    install_requires=['tqdm','openpyxl'],
    python_requires='>=3',
    py_modules=['daemontool'],
)
