from setuptools import setup
setup(
    name='dmutil',
    version='4.1.4',
    author='Daemon Huang',
    author_email='morningrocks@outlook.com',
    url='',
    install_requires=['tqdm','openpyxl', 'nuitka', 'cryptography'],
    python_requires='>=3.8',
    py_modules=['dmutil'],
)
