from setuptools import setup
setup(
    name='dmutils',
    version='1.1',
    author='Daemon Huang',
    author_email='morningrocks@outlook.com',
    url='',
    install_requires=['tqdm','openpyxl', 'nuitka', 'cryptography'],
    python_requires='>=3.8',
    py_modules=['dmutils'],
)
