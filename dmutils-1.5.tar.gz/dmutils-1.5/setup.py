from setuptools import setup
setup(
    name='dmutils',
    version='1.5',
    author='Daemon Huang',
    author_email='morningrocks@outlook.com',
    url='',
    install_requires=['tqdm','openpyxl', 'nuitka', 'cryptography', 'argparse'],
    python_requires='>=3.10',
    py_modules=['dmutils'],
)
